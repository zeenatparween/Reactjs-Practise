function Chai(){
    return(
        <h2>chai in react</h2>
    )
}

export default Chai